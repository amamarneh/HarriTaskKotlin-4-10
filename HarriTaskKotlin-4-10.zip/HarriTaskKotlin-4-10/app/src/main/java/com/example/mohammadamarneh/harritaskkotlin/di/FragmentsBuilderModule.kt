package com.example.mohammadamarneh.harritaskkotlin.di

import com.example.mohammadamarneh.harritaskkotlin.ui.countryDetailsFragment.CountryDetailsFragment
import com.example.mohammadamarneh.harritaskkotlin.ui.countryWeatherFragment.CountryWeatherFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class FragmentsBuilderModule {

    @ContributesAndroidInjector
    abstract fun contributeCountryDetailsFragment(): CountryDetailsFragment

    @ContributesAndroidInjector
    abstract fun contributeCountryWeatherFragment(): CountryWeatherFragment

}
