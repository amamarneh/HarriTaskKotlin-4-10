package com.example.mohammadamarneh.harritaskkotlin.ui.countryActivity

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import com.example.mohammadamarneh.harritaskkotlin.model.Weather
import com.example.mohammadamarneh.harritaskkotlin.ui.countryWeatherFragment.CountryWeatherFragment

class WeatherPagerAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm) {

    private val weatherFragments: Array<CountryWeatherFragment?>

    init {
        weatherFragments = arrayOfNulls(count)
    }

    override fun getItem(position: Int): Fragment {
        if (weatherFragments[position] == null) {
            weatherFragments[position] = CountryWeatherFragment.newInstance()
        }
        return weatherFragments[position]!!
    }

    override fun getCount() = 2

    fun updateData(weathers: List<Weather>) {
        if (weatherFragments[0] != null && weathers.isNotEmpty())
            weatherFragments[0]!!.showWeather(weathers[0])

        if (weatherFragments[1] != null && weathers.size > 1)
            weatherFragments[1]!!.showWeather(weathers[1])
    }
}