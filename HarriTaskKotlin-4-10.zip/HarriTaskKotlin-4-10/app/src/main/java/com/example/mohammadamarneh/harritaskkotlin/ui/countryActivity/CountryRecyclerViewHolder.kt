package com.example.mohammadamarneh.harritaskkotlin.ui.countryActivity

import android.support.v7.widget.RecyclerView
import com.example.mohammadamarneh.harritaskkotlin.databinding.ItemCountryBinding

class CountryRecyclerViewHolder (var binding: ItemCountryBinding) : RecyclerView.ViewHolder(binding.root)