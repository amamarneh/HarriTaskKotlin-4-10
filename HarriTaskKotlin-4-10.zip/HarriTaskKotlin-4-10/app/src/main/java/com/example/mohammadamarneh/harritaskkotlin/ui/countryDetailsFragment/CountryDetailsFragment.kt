package com.example.mohammadamarneh.harritaskkotlin.ui.countryDetailsFragment

import android.arch.lifecycle.ViewModelProviders
import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.mohammadamarneh.harritaskkotlin.R
import com.example.mohammadamarneh.harritaskkotlin.databinding.FragmentCountryDetailsBinding
import com.example.mohammadamarneh.harritaskkotlin.di.Injectable
import com.example.mohammadamarneh.harritaskkotlin.model.Country
import com.example.mohammadamarneh.harritaskkotlin.viewModel.ViewModelFactory
import timber.log.Timber
import javax.inject.Inject

class CountryDetailsFragment : Fragment(), Injectable {

    private var viewModel: CountryDetailsFragmentViewModel? = null
    @Inject
    lateinit var factory: ViewModelFactory

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Timber.d("fragment created")

    }

    fun showCountry(country: Country) = viewModel!!.loadCountry(country)

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        viewModel = ViewModelProviders.of(this, factory).get(CountryDetailsFragmentViewModel::class.java)
        val binding = DataBindingUtil.inflate<FragmentCountryDetailsBinding>(inflater, R.layout.fragment_country_details, container, false)
        binding.setLifecycleOwner(this)
        binding.viewModel = viewModel
        return binding.root
    }
}