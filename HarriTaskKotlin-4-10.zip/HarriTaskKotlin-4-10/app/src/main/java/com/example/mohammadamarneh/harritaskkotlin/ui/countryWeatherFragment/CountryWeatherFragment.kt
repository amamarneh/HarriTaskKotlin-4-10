package com.example.mohammadamarneh.harritaskkotlin.ui.countryWeatherFragment

import android.arch.lifecycle.ViewModelProviders
import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.mohammadamarneh.harritaskkotlin.R
import com.example.mohammadamarneh.harritaskkotlin.databinding.FragmentCountryWeatherBinding
import com.example.mohammadamarneh.harritaskkotlin.di.Injectable
import com.example.mohammadamarneh.harritaskkotlin.model.Weather
import com.example.mohammadamarneh.harritaskkotlin.viewModel.ViewModelFactory
import timber.log.Timber
import javax.inject.Inject

class CountryWeatherFragment : Fragment(), Injectable {

    private var viewModel: CountryWeatherFragmentViewModel? = null
    @Inject
    lateinit var factory: ViewModelFactory

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Timber.d("fragment created")

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        viewModel = ViewModelProviders.of(this, factory).get(CountryWeatherFragmentViewModel::class.java)
        val binding = DataBindingUtil.inflate<FragmentCountryWeatherBinding>(inflater, R.layout.fragment_country_weather, container, false)
        binding.setLifecycleOwner(this)
        binding.viewModel = viewModel
        return binding.root
    }

    fun showWeather(weather: Weather) = viewModel!!.loadWeather(weather)

    companion object {

        fun newInstance(): CountryWeatherFragment {
            val fragment = CountryWeatherFragment()
            val args = Bundle()
            fragment.arguments = args
            return fragment
        }
    }
}
