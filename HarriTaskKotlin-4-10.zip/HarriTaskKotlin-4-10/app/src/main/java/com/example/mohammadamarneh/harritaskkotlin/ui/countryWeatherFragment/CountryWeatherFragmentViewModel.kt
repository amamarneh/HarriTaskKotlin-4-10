package com.example.mohammadamarneh.harritaskkotlin.ui.countryWeatherFragment

import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel

import com.example.mohammadamarneh.harritaskkotlin.model.Weather

import javax.inject.Inject

class CountryWeatherFragmentViewModel @Inject constructor() : ViewModel() {
    //for dataBinding
    var date = MutableLiveData<Long>()
    var maxTemp = MutableLiveData<Float>()
    var minTemp = MutableLiveData<Float>()
    var pressure = MutableLiveData<Float>()
    var humidity = MutableLiveData<Int>()

    fun loadWeather(weather: Weather) {
        date.postValue(weather.date)
        maxTemp.postValue(weather.maxTemp)
        minTemp.postValue(weather.minTemp)
        pressure.postValue(weather.pressure)
        humidity.postValue(weather.humidity)
    }

}
