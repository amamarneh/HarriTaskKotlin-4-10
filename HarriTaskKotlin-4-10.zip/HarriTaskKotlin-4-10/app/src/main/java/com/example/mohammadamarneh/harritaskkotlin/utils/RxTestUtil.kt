package com.example.mohammadamarneh.harritaskkotlin.utils

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.Observer
import io.reactivex.Single
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.function.BiConsumer


object RxTestUtil {
    fun <T> getValue(single: Single<T>): T {
        val data = arrayOfNulls<Any>(1)
        val latch = CountDownLatch(1)
        val observer = object : Observer<T> {
            override fun onChanged(o: T?) {
                data[0] = o
                latch.countDown()
            }
        }
        single.subscribe()
       // liveData.observeForever(observer)
        latch.await(2, TimeUnit.SECONDS)

        @Suppress("UNCHECKED_CAST")
        return data[0] as T
    }
}