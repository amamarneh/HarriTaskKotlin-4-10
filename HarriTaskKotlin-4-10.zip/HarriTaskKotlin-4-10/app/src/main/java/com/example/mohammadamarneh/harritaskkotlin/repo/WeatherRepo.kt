package com.example.mohammadamarneh.harritaskkotlin.repo

import com.example.mohammadamarneh.harritaskkotlin.model.Weather
import com.example.mohammadamarneh.harritaskkotlin.network.NetworkConstants
import com.example.mohammadamarneh.harritaskkotlin.network.weatherApi.WeatherApiService
import com.example.mohammadamarneh.harritaskkotlin.network.weatherApi.response.Main
import com.example.mohammadamarneh.harritaskkotlin.utils.DateUtils

import java.util.ArrayList

import javax.inject.Inject

/**
 * Repository that handles Weather objects.
 */
class WeatherRepo @Inject constructor(private val apiService: WeatherApiService) {

    //returns list of two weathers, for today and tomorrow.
    fun getWeatherForecast(lat: Float, lon: Float)
        = apiService.getWeatherForecast(lat, lon, NetworkConstants.OPEN_WEATHER_KEY)
                .map { response ->
                    val result = ArrayList<Weather>()
                    var todaySetted = false
                    for (i in 0 until response.list.size) {
                        val dat = response.list[i].dt_txt
                        if (DateUtils.isToday(dat) && !todaySetted) {
                            val weather = getWeatherFromResponse(response.list[i].main)
                            weather.date = DateUtils.getTimeInMilliSecondsFromStringDate(dat)
                            result.add(weather)
                            todaySetted = true
                        } else if (DateUtils.isTomorrow(dat)) {
                            val weather = getWeatherFromResponse(response.list[i].main)
                            weather.date = DateUtils.getTimeInMilliSecondsFromStringDate(dat)
                            result.add(weather)
                        }
                    }
                    result
                }

    private fun getWeatherFromResponse(main: Main): Weather {
        val weather = Weather()
        weather.maxTemp = main.temp_max
        weather.minTemp = main.temp_min
        weather.humidity = main.humidity
        weather.pressure = main.pressure
        return weather
    }
}
