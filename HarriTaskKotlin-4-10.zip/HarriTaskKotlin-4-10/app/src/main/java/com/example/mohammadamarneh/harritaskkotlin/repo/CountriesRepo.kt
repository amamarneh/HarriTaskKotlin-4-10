package com.example.mohammadamarneh.harritaskkotlin.repo

import com.example.mohammadamarneh.harritaskkotlin.di.CountriesApi
import com.example.mohammadamarneh.harritaskkotlin.model.Country
import com.example.mohammadamarneh.harritaskkotlin.network.CountriesApiService

import javax.inject.Inject

import io.reactivex.Single
import javax.inject.Singleton

/**
 * Repository that handles Country objects.
 */
@Singleton
class CountriesRepo @Inject constructor(@CountriesApi private val countriesApiService: CountriesApiService) {

    val allCountries: Single<List<Country>>
        get() = countriesApiService.allCountries
}
