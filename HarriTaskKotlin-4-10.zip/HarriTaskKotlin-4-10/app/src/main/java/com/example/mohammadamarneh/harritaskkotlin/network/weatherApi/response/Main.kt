package com.example.mohammadamarneh.harritaskkotlin.network.weatherApi.response

data class Main(val temp_min: Float,
                val temp_max: Float,
                val pressure: Float,
                val humidity: Int)
