package com.example.mohammadamarneh.harritaskkotlin.network.weatherApi.response

data class GetWeatherResponse(val list: List<Data>)
