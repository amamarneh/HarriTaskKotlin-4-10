package com.example.mohammadamarneh.harritaskkotlin.ui.countryActivity

import android.databinding.DataBindingUtil
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import com.example.mohammadamarneh.harritaskkotlin.R
import com.example.mohammadamarneh.harritaskkotlin.databinding.ItemCountryBinding
import com.example.mohammadamarneh.harritaskkotlin.model.Country

class CountriesRecyclerViewAdapter (
        private var list: List<Country>,
        private val layoutInflater: LayoutInflater,
        private val listener: Listener
) : RecyclerView.Adapter<CountryRecyclerViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryRecyclerViewHolder {
        val binding = DataBindingUtil.inflate<ItemCountryBinding>(layoutInflater, R.layout.item_country, parent, false)
        return CountryRecyclerViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CountryRecyclerViewHolder, position: Int) {
        holder.binding.root.setOnClickListener { listener.onCountryClicked(list[position], position) }
        holder.binding.bean = list[position]
    }

    override fun getItemCount(): Int {
        return list.size
    }

    internal fun updatelist(countries: List<Country>) {
        this.list = countries
        notifyDataSetChanged()
    }

    interface Listener {
        fun onCountryClicked(country: Country, position: Int)
    }
}
