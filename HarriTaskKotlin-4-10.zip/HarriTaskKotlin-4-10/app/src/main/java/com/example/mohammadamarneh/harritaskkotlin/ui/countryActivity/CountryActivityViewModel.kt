package com.example.mohammadamarneh.harritaskkotlin.ui.countryActivity

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import com.example.mohammadamarneh.harritaskkotlin.di.CountriesApi

import com.example.mohammadamarneh.harritaskkotlin.model.Country
import com.example.mohammadamarneh.harritaskkotlin.model.Weather
import com.example.mohammadamarneh.harritaskkotlin.repo.CountriesRepo
import com.example.mohammadamarneh.harritaskkotlin.repo.WeatherRepo

import javax.inject.Inject

import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.observers.DisposableSingleObserver
import io.reactivex.schedulers.Schedulers

class CountryActivityViewModel @Inject constructor(private val countriesRepo: CountriesRepo, private val weatherRepo: WeatherRepo) : ViewModel() {
    var resultLive: MutableLiveData<List<Country>>? = null
        private set
    val errorLive = MutableLiveData<String>()
    private var disposableSingleObserver: DisposableSingleObserver<List<Country>>? = null
    var selectedPosition: Int = 0

    fun init() {
        if (resultLive != null) {
            return
        }

        resultLive = MutableLiveData()
        disposableSingleObserver = object : DisposableSingleObserver<List<Country>>() {
            override fun onSuccess(countries: List<Country>) {
                resultLive!!.postValue(countries)
            }

            override fun onError(e: Throwable) {
                errorLive.postValue(e.message)
            }
        }

        countriesRepo.allCountries
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(disposableSingleObserver!!)
    }

    fun getWeatherForTodayAndTomorrow(lat: Float, lon: Float): LiveData<List<Weather>> {
        val result = MutableLiveData<List<Weather>>()
        weatherRepo.getWeatherForecast(lat, lon)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : DisposableSingleObserver<List<Weather>>() {
                    override fun onSuccess(weathers: List<Weather>) {
                        result.postValue(weathers)
                    }

                    override fun onError(e: Throwable) {
                        errorLive.postValue(e.message)
                    }
                })
        return result
    }

    fun clear() = disposableSingleObserver!!.dispose()
}
