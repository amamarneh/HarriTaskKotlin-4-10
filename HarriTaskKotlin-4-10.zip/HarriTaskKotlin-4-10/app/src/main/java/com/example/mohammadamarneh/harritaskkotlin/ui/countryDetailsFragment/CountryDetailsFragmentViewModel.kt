package com.example.mohammadamarneh.harritaskkotlin.ui.countryDetailsFragment

import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import com.example.mohammadamarneh.harritaskkotlin.model.Country


import javax.inject.Inject

class CountryDetailsFragmentViewModel @Inject constructor() : ViewModel() {

    //for dataBinding
    var txtName = MutableLiveData<String>()
    var txtRegion = MutableLiveData<String>()
    var txtCapital = MutableLiveData<String>()
    var txtPopulation = MutableLiveData<Long>()
    var countryFlag = MutableLiveData<String>()

    fun loadCountry(country: Country) {
        txtName.postValue(country.name)
        txtCapital.postValue(country.capital)
        txtRegion.postValue(country.region)
        txtPopulation.postValue(country.population)
        countryFlag.postValue(country.alpha2Code)
    }
}
