package com.example.mohammadamarneh.harritaskkotlin.ui.countryActivity

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v4.app.Fragment
import android.support.v4.view.ViewPager
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.support.v7.app.ActionBarDrawerToggle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.view.View
import android.widget.Toast

import com.example.mohammadamarneh.harritaskkotlin.R
import com.example.mohammadamarneh.harritaskkotlin.model.Country
import com.example.mohammadamarneh.harritaskkotlin.ui.countryDetailsFragment.CountryDetailsFragment
import com.example.mohammadamarneh.harritaskkotlin.viewModel.ViewModelFactory
import dagger.android.DispatchingAndroidInjector
import dagger.android.support.HasSupportFragmentInjector

import javax.inject.Inject

class CountryActivity : AppCompatActivity(), CountriesRecyclerViewAdapter.Listener, HasSupportFragmentInjector {

    private var recyclerView: RecyclerView? = null
    private var countriesRecyclerViewAdapter: CountriesRecyclerViewAdapter? = null
    private var viewPager: ViewPager? = null
    private var weatherPagerAdapter: WeatherPagerAdapter? = null

    private var countryDetailsFragment: CountryDetailsFragment? = null

    @Inject
    lateinit var factory: ViewModelFactory
    private var viewModel: CountryActivityViewModel? = null

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Fragment>

    override fun supportFragmentInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_country)
        viewPager = findViewById(R.id.container)
        recyclerView = findViewById<View>(R.id.nav_view).findViewById(R.id.recyclerView)

        countryDetailsFragment = supportFragmentManager.findFragmentById(R.id.countryDetailFragment) as CountryDetailsFragment

        setupActionBar()

        setupTabsAndViewPager()

        initViewModel()
    }

    private fun setupActionBar() {
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        val drawer = findViewById<DrawerLayout>(R.id.drawer_layout)
        setSupportActionBar(toolbar)

        val toggle = ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close)
        drawer.addDrawerListener(toggle)
        toggle.syncState()
    }

    private fun setupTabsAndViewPager() {
        weatherPagerAdapter = WeatherPagerAdapter(supportFragmentManager)
        viewPager!!.adapter = weatherPagerAdapter
        val tabLayout = findViewById<TabLayout>(R.id.tabs)
        tabLayout.setupWithViewPager(viewPager)
        viewPager!!.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(tabLayout))
        tabLayout.addOnTabSelectedListener(TabLayout.ViewPagerOnTabSelectedListener(viewPager))
        tabLayout.getTabAt(0)!!.text = getString(R.string.today)
        tabLayout.getTabAt(1)!!.text = getString(R.string.tomorrow)
    }

    private fun initViewModel() {
        viewModel = ViewModelProviders.of(this, factory).get(CountryActivityViewModel::class.java)
        viewModel!!.init()

        viewModel!!.resultLive!!.observe(this, Observer { countries ->
            if (countries != null) {
                if (countriesRecyclerViewAdapter == null) {
                    countriesRecyclerViewAdapter = CountriesRecyclerViewAdapter(countries, layoutInflater, this)
                    recyclerView!!.layoutManager = LinearLayoutManager(this@CountryActivity)
                    recyclerView!!.adapter = countriesRecyclerViewAdapter
                } else {
                    countriesRecyclerViewAdapter!!.updatelist(countries)
                    countriesRecyclerViewAdapter!!.notifyDataSetChanged()
                }

                //show details of first country
                if (countries.size > viewModel!!.selectedPosition) {
                    onCountryClicked(countries.get(viewModel!!.selectedPosition), viewModel!!.selectedPosition)
                }
            }
        })

        viewModel!!.errorLive.observe(this, Observer { s -> Toast.makeText(this, s, Toast.LENGTH_LONG).show() })
    }

    override fun onBackPressed() {
        if (!hideDrawer())
            super.onBackPressed()
    }

    private fun hideDrawer(): Boolean {
        val drawer = findViewById<DrawerLayout>(R.id.drawer_layout)
        return if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START)
            true
        } else {
            false
        }
    }


    override fun onCountryClicked(country: Country, position: Int) {
        countryDetailsFragment!!.showCountry(country)
        viewModel!!.getWeatherForTodayAndTomorrow(country.latlng!![0], country.latlng!![1]).observe(this@CountryActivity, Observer{ weathers ->
            if (weathers != null && weathers!!.size > 0) {
                weatherPagerAdapter!!.updateData(weathers!!)
            }
        })
        hideDrawer()

        viewModel!!.selectedPosition = position
    }
}
