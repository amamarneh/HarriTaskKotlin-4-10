package com.example.mohammadamarneh.harritaskkotlin.network.weatherApi.response

data class Data(val main: Main,
                val dt_txt: String)
